var redColor = 123;
var greenColor = 39;
var blueColor = 21;

var x = 100;
var y = 200;
var diameter = 50;
 // this function is called only once

function setup() {
  createCanvas(300, 500);
   movement = Math.floor(Math.random() * 10) + 1;
}

function draw() {
  background(250, 0, 0);
  circle(x,y,70);
  if (x != 500)
  {
    x+=10;
  }
  square(x,y,90);
  y++;
  if (y != 500)
  {
    y+=10;
  }
  rect(x,y,30,60);
  x++;
  if (x != 500)
  {
    x+=7;
  }
  rect(x,y,30,56);
  y++;
  triangle(x, y, 150, 90, 190, 130);
  y++;
  textSize(45);
    text('Here I Am', 55, 70);
   textSize(32);
    text('Jessica Brooks', 50, 400);
}